#include <stdio.h>
#include "REG51.h"
#include "Delay.h"
// #include "case.h"

#define ANum 10

int main()
{   
	int acc_x,acc_y,acc_z;
	int tmp;
	unsigned char payload[1+2+6*ANum];
	unsigned char i;	

	// initialization of Temp Sensor
	//tmpInit();           //initialization of tmp100 			
		
	// data read from Temp Sensor
	//tmpGetTmpCont(&tmp);
	payload[0]=(unsigned char)((tmp&0xFF00)>>8);
	payload[1]=(unsigned char)(tmp&0x00FF);
	
	// initialization of ACM Sensor				
	//KXTJ9_Init();				      // ACM Sensor			
	//KXTJ9_Set_Resolution(1);	// high res
	//KXTJ9_Set_Range(2);			  // -2g -- +2g	
	
	// data read from ACM Sensor
	for(i=1;i<=ANum;i++)
	{
		//KXTJ9_Get_Acceleration(&acc_x, &acc_y, &acc_z);//wait(1,100);
		payload[6*i-4]=(unsigned char)((acc_x&0xFF00)>>8);
		payload[6*i-3]=(unsigned char)(acc_x&0x00FF);
		payload[6*i-2]=(unsigned char)((acc_y&0xFF00)>>8);
		payload[6*i-1]=(unsigned char)(acc_y&0x00FF);
		payload[6*i]=(unsigned char)((acc_z&0xFF00)>>8);
		payload[6*i+1]=(unsigned char)(acc_z&0x00FF);
		printf("%d\n", payload[1]);
	}
	
	//drill_buffer();
	//DelayMS(100);
	//nvrf_start(PNum,0);
	//DelayMS(200);
	
		
	//tmpInit();           //initialization of tmp100 		
	//tmpSetRes(3);        //Set resolution of tmp100: 12bits
	

	//tmpGetTmpCont(&tmp);
	payload[0]=(unsigned char)((tmp&0xFF00)>>8);
	payload[1]=(unsigned char)(tmp&0x00FF);		  

	//send_message(payload);

	return 0;
}
